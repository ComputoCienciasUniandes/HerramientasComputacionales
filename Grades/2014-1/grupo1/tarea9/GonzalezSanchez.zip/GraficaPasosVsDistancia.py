import matplotlib.pyplot as mt
import numpy as np

y, x = np.loadtxt('marcha-aleatoria.dat', unpack=True, usecols=[3,4])
mt.scatter(x, y, c='k')
mt.xlabel("Distancia recorrida", fontsize=20)
mt.ylabel("Numero de pasos", fontsize=20)
mt.title ("Distancia recorrida contra el numero de pasos")
mt.savefig('Npasos-r')
