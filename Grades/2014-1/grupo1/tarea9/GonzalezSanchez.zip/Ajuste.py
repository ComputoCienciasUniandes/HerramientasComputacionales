import matplotlib.pyplot as mt
import numpy as np
from scipy.optimize import curve_fit

y, x = np.loadtxt('marcha-aleatoria.dat', unpack=True, usecols=[3,4])
Y = np.log(y)
X = np.log(x)
def exponencial(x,a,b,c):
    return a -b*np.exp(-1*c*x)
pars, covar = curve_fit(exponencial, x, y)
mt.plot(x, exponencial(x, *pars), linewidth = 1)
mt.scatter(x, y)
mt.text(0, 1,'matplotlib', horizontalalignment='center', verticalalignment='center', transform=ax.transAxes)
mt.ylabel("Distancia recorrida", fontsize=20)
mt.xlabel("Numero de pasos", fontsize=20)
mt.title ("Distancia recorrida contra el numero de pasos")
mt.savefig('Ajuste')
