import numpy as np

x=0
y=0
z=0
nPasos = 0
r=0
NPasos = []
X=[]
Y=[]
Z=[]
R=[]
Radio = input()
while (r<Radio):
    X.append(x)
    Y.append(y)
    Z.append(z)
    NPasos.append(nPasos)
    R.append(r)
    theta = np.random.rand()*2*3.1416
    phi = 3.1416*np.random.rand()
    x= x + np.cos(theta)*np.sin(phi)
    y= y + np.sin(theta)*np.sin(phi)
    z= z + np.cos(phi)
    nPasos += 1
    r=(x**2+y**2+z**2)**(0.5)



np.savetxt('marcha-aleatoria.dat', np.column_stack((X,Y,Z,NPasos,R)))



