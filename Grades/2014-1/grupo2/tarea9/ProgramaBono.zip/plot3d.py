__author__ = 'David'
import numpy as np
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import sys


st = str(sys.argv[1])


data = np.loadtxt(st)
x = data[:, 0]
y = data[:, 1]
z = data[:, 2]


fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(x,y,z)
ax.set_xlabel('X Label')
ax.set_ylabel('Y Label')
ax.set_zlabel('Z Label')

u, v = np.mgrid[0:2*np.pi:20j, 0:np.pi:10j]
x=10*np.cos(u)*np.sin(v)
y=10*np.sin(u)*np.sin(v)
z=10*np.cos(v)
ax.plot_wireframe(x, y, z, color="r")
plt.savefig('3dplot.png')
plt.show()

