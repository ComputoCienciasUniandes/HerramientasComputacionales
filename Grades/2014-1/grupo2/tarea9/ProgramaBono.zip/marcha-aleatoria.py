__author__ = 'David'

import numpy as np
import sys
import scipy as sp
import matplotlib as mp
import matplotlib.pyplot as plt

st = str(sys.argv[1])

data = np.loadtxt(st)

fig = plt.figure(figsize=(9, 9))
plt.scatter(data[:, 3], data[:, 4])
plt.xlabel("Numero de pasos", fontsize=15)
plt.ylabel("Distancia", fontsize=15)
plt.title("Figura de distancia contra pasos", fontsize=35)
plt.savefig('Npasos-r.png')
plt.show()
