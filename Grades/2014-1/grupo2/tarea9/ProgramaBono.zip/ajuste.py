__author__ = 'David'

import numpy as np
import sys
import scipy as sp
import matplotlib as mp
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

st = str(sys.argv[1])

def sinfunc(x,a,b):
    return a*np.sin(x-b)


data = np.loadtxt(st)
x = data[:, 3]
y = data[:, 4]
fit = np.polyfit(x,y,1)
fit1 = np.polyfit(x,y,2)
fitpars, covmat = curve_fit(sinfunc,x,y)
plt.plot(x, sinfunc(x, fitpars[0], fitpars[1]), 'r-', label="Sinosoidal")
plt.plot(x, x*fit1[0]**2 + fit1[1]*x + fit1[2], linewidth='2.0', label="cuadratico")
plt.plot(x, x*fit[0] + fit[1], linewidth='2.0', label="lineal")
plt.scatter(x, y, c='k', alpha=0.7)
plt.legend(loc='best')
plt.xlabel("$\mathrm{Pasos}$", fontsize=25)
plt.ylabel("$\mathrm{Distancia}$", fontsize=25)
plt.title("$\mathrm{Regresion\ utilizando \ varios \ polinomios}$", fontsize=25)
plt.figtext(0,0.04,  'la ecuacion lineal es: ' + str(fit[0]) + ' x ' + ' + ' + str(fit[1]), backgroundcolor='silver', color='black', weight='roman')
plt.savefig('ajuste.png')
plt.show()


