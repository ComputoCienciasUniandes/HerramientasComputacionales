import numpy as np
import random 
import sys 
import math as mt

Radio = float(sys.argv[1])


i = 0
x = 0
y = 0
z = 0
distancia = 0
posx = []
posy = []
posz = []
N = []
distancias = []

while distancia<Radio:
   i+=1
   teta = np.random.rand()
   phi = np.random.rand()
   x = x + mt.cos(2*mt.pi*teta)*mt.sin(2*mt.pi*phi)
   y = y + mt.sin(2*mt.pi*teta)*mt.sin(2*mt.pi*phi) 
   z = z + mt.sin(2*mt.pi*teta)
   distancia = mt.sqrt( (x**2) + (y**2) + (z**2))+distancia
   posx.append(x)
   posy.append(y)
   posz.append(z)
   N.append(i)
   distancias.append(distancia)


file = open("random.dat", "w")
for j in range(len(posx)):
     file.write(str(N[j])+ " " + str(posx[j]) + " " + str(posy[j]) + " " + str(posz[j]) + " " + str(distancias[j]) + "\n" )
file.close  
