import numpy as np
import sys
import matplotlib.pyplot as plt
import scipy.optimize as sc


if(len(sys.argv)!=2):
    print "ingrese argumento"
    exit(1)
nombre = str(sys.argv[1])
print nombre
popo = np.loadtxt(nombre)

x = popo[:,0]
y = popo[:,4]

fit = sc.polyfit(x, y, 2)
plot(x, fit[0]*x**2 + fit[1]*x + fit[2], linewidth=2.5)
scatter(x, y, c='k')
xlabel("$\mathrm{x}$", fontsize=25)
ylabel("$\mathrm{y}$", fontsize=25)
yteo = fit[0]*x**2 + fit[1]*x + fit[2]
plt.savefig("cacaMayor")
