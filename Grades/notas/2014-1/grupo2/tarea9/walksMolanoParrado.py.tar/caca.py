import numpy as np
import sys
import matplotlib.pyplot as plt

if(len(sys.argv)!=2):
    print "ingrese argumento"
    exit(1)
nombre = str(sys.argv[1])
print nombre
popo = np.loadtxt(nombre)

pasos = popo[:,0]
dist = popo[:,4]

plt.scatter(pasos,dist)
xlabel("$Pasos$", fontsize=30)
ylabel("$Distancia$", fontsize=30)
plt.savefig("cacota.png")



