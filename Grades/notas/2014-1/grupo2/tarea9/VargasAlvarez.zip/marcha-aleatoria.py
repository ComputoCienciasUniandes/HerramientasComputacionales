import numpy as np
import matplotlib.pyplot as plt
import sys

R = sys.argv[1] 
lr = []
ln = []

def esfera(radio):
    r = 0
    x = 0
    y = 0
    z = 0
    Npasos = 0
    while(r < radio):
        t = 2 * np.pi * np.random.rand(0, 1)
        s = 2 * np.pi * np.random.rand(0, 1)
        x = x + np.cos(t)
        y = y + np.sin(t)
        z = z + np.sin(s)
        r = np.sqrt(x**2 + y**2 + z**2)
        Npasos = Npasos + 1

        lr.append(r)
        ln.append(Npasos)
    return x, y, z, Npasos, r

esfera(R)

plt.plot(lr, ln)
plt.xlabel("distancia r", fontsize = 30)
plt.ylabel("numero de pasos", fontsize = 30)
plt.title("Npasos vs r", fontsize = 30)


