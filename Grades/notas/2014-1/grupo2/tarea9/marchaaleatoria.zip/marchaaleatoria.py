__author__ = 'David'
import numpy as np

import sys
import time

phi = 0
theta = 0
R = int(sys.argv[1])
r = 0
xlist = [0]
ylist = [0]
zlist = [0]
rlist = [0]

while ( r <  R):
    phi = np.pi*2*np.random.random_sample()
    theta = np.pi*np.random.random_sample()
    x = np.sin(theta)*np.cos(phi)
    y = np.sin(phi)*np.sin(theta)
    z = np.cos(theta)
    xlist.append(x+xlist[len(xlist)-1])
    ylist.append(y+ylist[len(ylist)-1])
    zlist.append(z+zlist[len(zlist)-1])
    r = np.sqrt(xlist[len(xlist)-1]**2 + ylist[len(ylist)-1]**2 + zlist[len(zlist)-1]**2)
    rlist.append(r)


f = open("marcha-aleatoria.dat", "w")
for i in range(len(xlist)):
    f.write(str(xlist[i]) + " " + str(ylist[i]) + " " + str(zlist[i]) + " " + str(i) + " " + str(rlist[i]) + "\n")
f.close







